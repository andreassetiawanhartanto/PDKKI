<?php
defined('_JEXEC') or die('Restricted access'); 
include_once(JPATH_SITE.DS.'components'.DS.'com_chronocontact'.DS.'libraries'.DS.'includes'.DS.'JSvalidation.php')
?>