if (typeof jQuery !== 'undefined') {
	jQuery.noConflict();
}
