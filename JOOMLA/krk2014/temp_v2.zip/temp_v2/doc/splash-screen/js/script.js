$(document).ready(function(){
	
	// Calling our splashScreen plugin and
	// passing an array with images to be shown
	
	$('#promoIMG').splashScreen({
		textLayers : [
			'img/thinner.png',
			'img/more_elegant.png',
			'img/our_new.png'
		]
	});
	
});
